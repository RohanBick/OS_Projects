#include <stdio.h>
int main() {
   printf("OS ASSIGNMENT-1 (C Program) \n");
   printf("Hi! I am Rohan Bhowmick \n");
   printf("This is my first C program for OS Assignment-1");
   return 0;
}
