# Readme for Task-6

## How to test your solution?

Run your solution; check the directories to see if you find the desired
files in them. Also, use `tar tvzf` to check the files in the
`rest_zipped.tar.gz`. 


## Clean command

    $ make clean
